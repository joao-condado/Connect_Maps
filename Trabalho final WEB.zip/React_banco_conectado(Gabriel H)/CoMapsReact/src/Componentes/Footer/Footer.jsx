function Footer(){
    return(
        <footer>
            <p>Todos os direitos reservados a  <strong>© Gian's Company.Ltda</strong></p>
        </footer>
    )
}
export default Footer