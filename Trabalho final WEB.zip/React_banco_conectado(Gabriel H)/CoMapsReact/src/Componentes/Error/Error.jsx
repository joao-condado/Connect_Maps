import styles from './../Error/Error.module.css';

function Error(){
    return(
        <div>
            <h1 className={styles.erro}>Putz... não achei essa pagina <span> :(</span></h1>
        </div>
    )
}
export default Error