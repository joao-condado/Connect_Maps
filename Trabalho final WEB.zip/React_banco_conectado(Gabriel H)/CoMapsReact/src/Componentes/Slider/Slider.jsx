import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './Slider.module.css'; 

const Slider = () => {
    const [currentIndex, setCurrentIndex] = useState(0);
    const totalSlides = 3; 

    useEffect(() => {
        const interval = setInterval(() => {
            setCurrentIndex((prevIndex) => (prevIndex + 1) % totalSlides);
        }, 5000); 

        return () => clearInterval(interval); 
    }, []);


    return (
        <section className={styles.slider}>
            <div className={styles.sliderContent}>
                <input type="radio" name="radio" id={styles.radio1} checked={currentIndex === 0} readOnly />
                <input type="radio" name="radio" id={styles.radio2} checked={currentIndex === 1} readOnly />
                <input type="radio" name="radio" id={styles.radio3} checked={currentIndex === 2} readOnly />

                <div className={styles.slideBox} style={{ display: currentIndex === 0 ? 'block' : 'none' }}>
                    <Link to="/denuncia" className={`${styles.linkSlide} ${styles.img1Slider}`}>
                        Algo que considera um risco em sua região? Denuncie.
                    </Link>
                </div>
                <div className={styles.slideBox} style={{ display: currentIndex === 1 ? 'block' : 'none' }}>
                    <Link to="/" className={`${styles.linkSlide} ${styles.img2Slider}`}>
                        Atualizações dos mapas de risco de deslizamento em Bragança Paulista
                    </Link>
                </div>
                <div className={styles.slideBox} style={{ display: currentIndex === 2 ? 'block' : 'none' }}>
                    <Link to="/" className={`${styles.linkSlide} ${styles.img3Slider}`}>
                        Alerta: Forte chuvas em São Paulo
                    </Link>
                </div>

                <div className={styles.navManual}>
                    <label htmlFor="radio1" className={styles.manualBtn} onClick={() => setCurrentIndex(0)}></label>
                    <label htmlFor="radio2" className={styles.manualBtn} onClick={() => setCurrentIndex(1)}></label>
                    <label htmlFor="radio3" className={styles.manualBtn} onClick={() => setCurrentIndex(2)}></label>
                </div>
            </div>
        </section>
    );
};

export default Slider;