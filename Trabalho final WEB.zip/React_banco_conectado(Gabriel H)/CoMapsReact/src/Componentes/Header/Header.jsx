import { Link } from "react-router-dom"
import '../../App.css';
import imageLogo from '../../img/logo/Connect.png';
import imageMobile from '../../img/logo/ConnectMobile.png';
//
import { FormContext } from "../../Context/FormContext";
import { useContext } from "react";


function Header() {
    const { formData } = useContext(FormContext)

    console.log(formData.email.slice(0, 4))

   let tam_email = formData.email.length

   let nome_email = ''

   if (tam_email > 5){
    nome_email = (formData.email.slice(0, 4) + "...")
   }
   else{
    nome_email = formData.email
   }

    // console.log(formData)
    return (
        <header>
            <Link to={"/"} className='logo'>
                <picture>
                    <source srcSet={imageMobile} media="(max-width: 845px)" />
                    <source srcSet={imageLogo} />
                    <img srcSet={imageLogo} alt="logo" />
                </picture>
            </Link>

            <nav className='menu'>
                <Link to={"/SaibaMais"} id="saiba-mais" className="menu-link">Saiba mais</Link>
                <Link to={"/SobreNos"} id="sobre-nos" className="menu-link"> Sobre nos</Link>
                <Link to={"/Login"} className="menu-link botao-login">{ nome_email || "Login" }</Link>
            </nav>

        </header>
    )
}
export default Header