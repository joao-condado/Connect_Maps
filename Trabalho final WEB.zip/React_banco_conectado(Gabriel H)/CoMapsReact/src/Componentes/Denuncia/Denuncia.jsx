import styles from './Denuncia.module.css';
import Map from '../Main/Map.jsx';
import { useForm } from "react-hook-form";
import axios from 'axios';
import { useNavigate } from "react-router-dom";

function Denuncia() {

    const navigate = useNavigate();
    const {
        register,
        handleSubmit,
        formState: { errors },
    } = useForm();

    const onSubmit = (data) => {
        
        console.log(data);
        criarDenuncia(data)
        navigate('/');
      };

    //   const criarDenuncia = async () => {
    //     // Dados fixos da denúncia
    //     const denunciaData = {
    //       descricao: "caos cibernético",
    //       grauDeRisco: "baixo",
    //       categoria: "Infraestrutura"
    //     };
    
    //     try {
    //       const response = await axios.post(
    //         "http://localhost:8080/denuncia/cadastrarDenuncia",
    //         denunciaData
    //       );
    //       console.log("Denúncia enviada com sucesso:", response.data);
    //     } catch (error) {
    //       console.error("Erro ao enviar a denúncia:", error);
    //     }
    //   };

    
      async function criarDenuncia(data) {
        // Variável predefinida
        const novaDenuncia = data;
  
        try {
            const response = await axios.post(
                'http://localhost:8080/denuncia/cadastrarDenuncia', 
                novaDenuncia
            );
  
            if (response.ok) {
                const result = await response.text(); // Pega a resposta como texto
                console.log('Postagem bem-sucedida:', result);
            } else {
                console.error('Erro na requisição:', response.status, response.statusText);
            }
        } catch (error) {
            console.error('Erro ao enviar a requisição:', error);
        }
    }

    return (
        <main id={styles.denuncia}>
            <form  id="form" autoComplete="off" onSubmit={handleSubmit(onSubmit)}>
                <h1>Denúncia</h1>

                <div className={styles.boxInput}>
                    <label htmlFor="categoria">Como você categoriza esse risco?:</label>
                    <input type="text" name="categoria" id="categoria" placeholder="Risco de..." maxLength="50"
                    {...register("categoria", {
                        required: "categoria inválida",
                        pattern: {
                          value: /^[a-zA-ZÀ-ÿ\s]{5,}$/, //minimo de 5 linhas
                          message: "Digite uma categoria de risco válida"
                        }
                      })}
                    />
                    {errors.categoria && <p>{errors.categoria.message}</p>}
                </div>

                <div className={styles.boxRadio}>
                    <p>Você diria que o nível desse risco é:</p>
                    <input type="radio" name="grauDeRisco" id="Baixo" value="Baixo"
                    {...register("grauDeRisco", {
                        required: "Selecione um nível de risco",
                    })} 
                    />
                    <label htmlFor="Baixo">Baixo</label>

                    <input type="radio" name="grauDeRisco" id="Moderado" value="Moderado" 
                    {...register("grauDeRisco", {
                        required: "Selecione um nível de risco",
                    })} 
                    />
                    <label htmlFor="Moderado">Moderado</label>

                    <input type="radio" name="grauDeRisco" id="Alto" value="Alto"
                    {...register("grauDeRisco", {
                        required: "Selecione um nível de risco",
                    })} 
                    />
                    <label htmlFor="Alto">Alto</label>
                    {errors.grauDeRisco && <p className={styles.error}>{errors.grauDeRisco.message}</p>}
                </div>

                <div className={styles.boxInput}>
                    <label htmlFor="descricao">Detalhes do risco:</label>
                    <textarea name="descricao" id={styles.descricao} rows="5" 
                    {...register("descricao", {
                        required: "Descricao inválida",
                        pattern: {
                          value: /^[a-zA-ZÀ-ÿ\s]{5,}$/, //minimo de 5 linhas
                          message: "Digite uma descrição de risco válida"
                        }
                      })}
                    ></textarea>
                    {errors.descricao && <p className={styles.error}>{errors.descricao.message}</p>}
                </div>

                <p>Click para adicionar o local de denúncia:</p>
                <div id={styles.map_denuncia}>
                    <Map />
                </div>

                {/* <div className={styles.boxInput}>
                    <label htmlFor="latitude">Latitude:</label>
                    <input type="text" name="latitude" id="latitude" />
                </div>

                <div className={styles.boxInput}>
                    <label htmlFor="longitude">Longitude:</label>
                    <input type="text" name="longitude" id="longitude" />
                </div> */}

                <div id={styles.botao}>
                    <button className={styles.btn} type="submit">Enviar</button>
                </div>
            </form>
        </main>
    )

}
export default Denuncia;

