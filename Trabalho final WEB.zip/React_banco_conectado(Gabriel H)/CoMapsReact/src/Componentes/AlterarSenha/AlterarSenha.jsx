// import { Link } from "react-router-dom"
import styles from "./AlterarSenha.module.css";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom"; //hook de navegação programável

function AlterarSenha() {

    const navigate = useNavigate(); // Inicializando o hook de navegação
    const {
        register,
        handleSubmit,
        watch,
        formState: { errors },
    } = useForm();

    const onSubmit = (data) => {
        console.log(data);
        navigate('/Login'); // Caminho para a página de login
        alert(JSON.stringify(data, null, 2));  // Exibe o objeto como string no alert
    };

    const senha = watch("senha");

    return (
        <main id={styles.alterar}>
            <form className={styles.form} autoComplete="off" onSubmit={handleSubmit(onSubmit)}>
                <h1>Alteração de Senha</h1>

                <div className={styles.boxInput}>
                    <label htmlFor="iemail">Email:</label>
                    <input type="email" name="email" id="iemail"
                        {...register("email", {
                            required: "O email é obrigatório",
                            pattern: {
                                value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                                message: "Digite um email válido"
                            }
                        })}
                    />
                    {errors.email && <p>{errors.email.message}</p>}
                </div>
                <div className={styles.boxInput}>
                    <label htmlFor="isenha">Senha:</label>
                    <input type="password" name="senha" id="isenha"
                        {...register("senha", {
                            required: "A senha é obrigatória",
                            pattern: {
                                value: /^.{6,}$/,
                                message: "A senha deve conter no mínimo 6 caracteres",
                            }
                        })}
                    />
                    {errors.senha && <p>{errors.senha.message}</p>}
                </div>

                <div className={styles.boxInput}>
                    <label htmlFor="iconfirmacao">Confirmação de senha:</label>
                    <input type="password" name="confirmacao" id="iconfirmacao"
                        {...register("confirmacao", {
                            required: "A confirmação de senha é obrigatória",
                            //funcionalidade do react-hook-form para validar um campo especifico
                            validate: (value) =>
                                value === senha || "As senhas não coincidem",
                        })}
                    />
                    {errors.confirmacao && <p>{errors.confirmacao.message}</p>}
                </div>

                <div id={styles.botao}>
                    <button className={styles.btn} type="submit">Entrar</button>
                </div>
            </form>
        </main>
    );


}

export default AlterarSenha;