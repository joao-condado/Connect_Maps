// src/MapComponent.js
import React from 'react';
import { MapContainer, TileLayer, Marker, Popup, Circle, Polygon } from 'react-leaflet';

function Map() {
    // Define as coordenadas do centro do mapa (latitude e longitude)
    const position = [-22.933462761769942, -46.55813999333214]; // 

    const markers = [
        { position: [-22.903425353800635, -46.54392242431641], label: "Área com risco de enchente" },
        { position: [-22.919370632734857, -46.567611694335945], label: "Área com risco de deslizamento" },
        { position: [-22.929420632734857, -46.547511694335945], label: "Área com risco de enchente" },
    ];

    const borda_braganca = [
        [-22.85014196527919, -46.642254066246416],
        [-22.83748617493972, -46.596248818130135],
        [-22.84128303568879, -46.55161686100239],
        [-22.823563445720566, -46.46715946520681],
        [-22.91277077185903, -46.465099528724],
        [-22.98358869118416, -46.40467472522797],
        [-23.02277551788617, -46.422527508079064],
        [-23.03288639969517, -46.47814579311518],
        [-23.02467136599143, -46.53513736913983],

        [-23.046088656064306, -46.564269793485714],
        [-23.020906622488873, -46.58168394562612],

        [-23.015823846775234, -46.609295082521314],
        [-23.000269902790713, -46.70130615036839],
        [-22.967152120912456, -46.720531652593536],
        [-22.955771786071807, -46.71297855215654],
        [-22.957036315011923, -46.698558996776804]
    ];

    return (
        <MapContainer

            center={position} // Centraliza o mapa nessas coordenadas
            zoom={12}         // Nível de zoom inicial (pode ajustar conforme necessário)
            style={{ height: '100%', width: '100%' }} // Tamanho do mapa
        >
            {/* TileLayer define o provedor de mapas, neste caso OpenStreetMap */}
            <TileLayer
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors & © Gians Company.Ltda'
            />
            {/* Marcador e popup */}
            {markers.map((marker, index) => (
                <Circle
                    center={marker.position} // Define a posição do centro do círculo
                    radius={500}  // Define o raio do círculo
                    color="red"           // Cor da borda do círculo
                    fillColor="red"       // Cor de preenchimento
                    fillOpacity={0.2}      // Opacidade de preenchimento
                >
                    <Marker key={index} position={marker.position}>
                        <Popup>{marker.label}</Popup>
                    </Marker>
                </Circle>
            ))}

            <Polygon
                positions={borda_braganca} // Define as coordenadas dos vértices do polígono
                color="blue"               // Cor da borda
                fillColor="none"           // Cor de preenchimento
                fillOpacity={0.3}            // Opacidade do preenchimento
            >
                <Popup>Este é um polígono personalizado!</Popup>
            </Polygon>


        </MapContainer>
    );
}
export default Map;
