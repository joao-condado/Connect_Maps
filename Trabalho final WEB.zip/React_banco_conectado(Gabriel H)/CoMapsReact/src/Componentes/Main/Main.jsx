import React, { useContext } from "react";
import styles from "./Main.module.css";
import { Link } from "react-router-dom";
import WeatherWidget from './WeatherWidget.jsx';
import Slider from '../Slider/Slider.jsx';
import Map from './Map.jsx';
import { FormContext } from "../../Context/FormContext.jsx";

function Main() {
  const { denuncias } = useContext(FormContext);

  return (
    <main className={styles.principal}>
      <div className={styles.container}>
        <Slider />
        <div className={styles.clima}>
          <WeatherWidget />
          <button className={styles.link}>mais detalhes</button>
        </div>

        <div id={styles.map}>
          <Map />
        </div>

        <div className={styles.infoDenuncias}>
          <h4>Denúncias Registradas</h4>
          {denuncias.length > 0 ? (
            <ul className={styles.denunciasList}>
              {denuncias.map((denuncia) => (
                <li className={styles.denunciaItem} key={denuncia.Id_Denuncia}>
                  <p>ID: {denuncia.Id_Denuncia}</p>
                  <p>Descrição: {denuncia.descricao}</p>
                  <p>Grau de Risco: {denuncia.grauDeRisco}</p>
                  <p>Categoria: {denuncia.categoria}</p>
                  <Link
                    to={`/denuncia/atualizar/${denuncia.Id_Denuncia}`}
                    className={styles.atualizarBtn}
                  >
                    Atualizar Denúncia
                  </Link>
                </li>
              ))}
            </ul>
          ) : (
            <p>Não há denúncias registradas.</p>
          )}
        </div>
        <div className={styles.mais_lidas}>
            <h2>Mais acessadas</h2>
            <Link to={"/AlterarSenha"}>Alterar Senha</Link>
            <a href="#">Enchente São Paulo</a>
            <a href="#">Deslizamento São Paulo</a>
            <a href="#">Enchente Bragança Paulista</a>
        </div>


        <div className={`${styles.mapa2} ${styles.cont_mapa}`}>
            <Link to={"/Denuncia"}>Escreva uma denuncia</Link>
        </div>



        <div className={styles.recentes}>
            <h2>Recentes</h2>
            <a href="#">Enchente São Paulo</a>
            <a href="#">Deslizamento São Paulo</a>
            <a href="#">Enchente Bragança Paulista</a>
        </div>

        <div className={`${styles.mapa3} ${styles.cont_mapa}`}>
            <a href="#">Mapas enchente Bragança Paulista</a>
        </div>
      </div>
    </main>
  );
}

export default Main;