import { useState, useEffect } from 'react';
import styles from "./Main.module.css";

function WeatherWidget() {
    const [weatherData, setWeatherData] = useState(null);
    const [error, setError] = useState(null);

    const cidade = "Bragança Paulista,BR";
    const apiKey = "486341088b283bf059a535838c69c0c5";

    useEffect(() => {
        const fetchWeather = async () => {
            try {
                const response = await fetch(
                    `https://api.openweathermap.org/data/2.5/weather?q=${cidade}&appid=${apiKey}&units=metric&lang=pt`
                );

                if (!response.ok) {
                    throw new Error("Erro ao buscar os dados do clima");
                }

                const data = await response.json();
                setWeatherData(data);
            } catch (error) {
                setError(error.message);
                console.error("Erro ao buscar dados climáticos:", error);
            }
        };

        fetchWeather();
    }, [cidade, apiKey]);

    const getWeatherIcon = (temp) => {
        if (temp > 30) {
            return '🔥'; // Muito quente
        } else if (temp > 25) {
            return '☀️'; // Quente
        } else if (temp > 15) {
            return '⛅'; // Ameno
        } else {
            return '❄️'; // Frio
        }
    };

    const getConditionIcon = (condition) => {
        if (condition.includes("chuva")) {
            return '🌧️'; // Chuva
        } else if (condition.includes("tempestade")) {
            return '⛈️'; // Tempestade
        } else if (condition.includes("nuvem")) {
            return '☁️'; // Nublado
        } else if (condition.includes("neve")) {
            return '🌨️'; // Neve
        } else {
            return '☀️'; // Céu limpo
        }
    };
    
    const getHumidityIcon = (humidity) => {
        if (humidity > 80) {
            return '💧💧'; // Muito úmido
        } else if (humidity > 50) {
            return '💧'; // Úmido
        } else {
            return '🌵'; // Seco
        }
    };

    return (
        <div>
            {error ? (
                <p>{error}</p>
            ) : weatherData ? (
                <div className={styles.WeatherWidget}>
                    <h3>{weatherData.name}</h3>
                    <ul>
                        <li style={{ fontSize: '40px' }}>{weatherData.main.temp}°C {getWeatherIcon(weatherData.main.temp)}</li>
                        <li className={styles.info_clima}>{weatherData.weather[0].description} {getConditionIcon(weatherData.weather[0].description)}</li>
                        <li className={styles.info_clima}>Umidade: {weatherData.main.humidity}% {getHumidityIcon(weatherData.main.humidity)}</li>
                    </ul>
                </div>
            ) : (
                <p>Carregando dados climáticos...</p>
            )}
        </div>
    );
}

export default WeatherWidget;
