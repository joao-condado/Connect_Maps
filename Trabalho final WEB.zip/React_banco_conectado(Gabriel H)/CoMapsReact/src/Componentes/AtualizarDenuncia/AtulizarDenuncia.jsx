import React, { useState } from 'react';
import styles from './AtualizarDenuncia.module.css';
import axios from 'axios';

function AtualizarDenuncia({ denuncia, onClose }) {
  const [descricao, setDescricao] = useState(denuncia.descricao);
  const [categoria, setCategoria] = useState(denuncia.categoria);
  const [grauDeRisco, setGrauDeRisco] = useState(denuncia.grauDeRisco);

  const handleSubmit = async (e) => {
    e.preventDefault();

    const updatedDenuncia = {
      ...denuncia,
      descricao,
      categoria,
      grauDeRisco,
    };

    try {
      await axios.put(`http://localhost :8080/denuncia/atualizar/${denuncia.Id_Denuncia}`, updatedDenuncia);
      alert('Denúncia atualizada com sucesso!');
      onClose();
    } catch (error) {
      console.error('Erro ao atualizar a denúncia:', error);
      alert('Erro ao atualizar a denúncia');
    }
  };

  return (
    <div className={styles.modalContent}>
      <h2>Atualizar Denúncia</h2>
      <form onSubmit={handleSubmit} className={styles.form}>
        <label>
          Descrição:
          <textarea
            value={descricao}
            onChange={(e) => setDescricao(e.target.value)}
          />
        </label>
        <label>
          Categoria:
          <input
            type="text"
            value={categoria}
            onChange={(e) => setCategoria(e.target.value)}
          />
        </label>
        <label>
          Grau de Risco:
          <input
            type="number"
            value={grauDeRisco}
            onChange={(e) => setGrauDeRisco(e.target.value)}
          />
        </label>
        <button type="submit" className={styles.submitBtn}>
          Atualizar
        </button>
        <button type="button" className={styles.closeBtn} onClick={onClose}>
          Cancelar
        </button>
      </form>
    </div>
  );
}

export default AtualizarDenuncia;
