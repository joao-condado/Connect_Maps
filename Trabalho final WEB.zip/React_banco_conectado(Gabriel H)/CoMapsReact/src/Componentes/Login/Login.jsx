import { Link } from "react-router-dom";
import styles from './Login.module.css';
import { useForm } from "react-hook-form";
//
import React, { useState, useContext, useEffect } from 'react';
//
import { FormContext } from "../../Context/FormContext";
//
import { useNavigate } from "react-router-dom";
//
import axios from "axios";


function Login() {

    // const { formData, setFormData } = useContext(FormContext)
    // const [name, setName] = useState('');
    // const [email, setEmail] = useState('');


    // const {
    //     register,
    //     handleSubmit,
    //     formState: { errors },
    // } = useForm();

    // Função para atualizar o estado conforme o usuário digita
    // const handleChange = (e) => {
    //     const { name, value } = e.target; // Extrai o nome e valor do campo
    //     setFormData({
    //       ...formData, // Mantém os outros valores do formData
    //       [name]: value // Atualiza o campo específico
    //     });
    // };

    //   Função para manipular o envio do formulário
    // const onSubmit = (data) => {
    //     console.log(data);
    //     alert(JSON.stringify(data, null, 2));  // Exibe o objeto como string no alert

    // };
    //   =-=-=-=-=-=-=-=-=-==-=-=-=-=-=-=-=-=-==-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-
    // const { setFormData } = useContext(FormContext); // Acesso ao contexto para atualizar os dados
    // const navigate = useNavigate();

    // const {
    //     register,
    //     handleSubmit,
    //     formState: { errors },
    // } = useForm();

    // // Função para manipular o envio do formulário
    // const onSubmit = (data) => {
    //     setFormData(data); // Atualiza o FormContext com os dados do formulário
    //     alert("Login realizado com sucesso!");
    //     console.log(data)
    //     // deletarCidadao(1)
    //     navigate('/')
    // };
    // //------------------------------
    // async function buscarCidadaos() {
    //     try {
    //         const resposta = await axios.get('http://localhost:8080/cidadao/todos');  // Faz a requisição GET
    //         const cidadaos = resposta.data;  // Armazena a resposta (lista de cidadãos)
    //         console.log(cidadaos);  // Exibe a lista no console ou use conforme necessário
    //     } catch (erro) {
    //         console.error('Erro ao buscar os cidadãos:', erro);
    //     }
    // }
    // buscarCidadaos()

    //------------------------------------------

    // const deletarCidadao = async (id) => {
    //     try {
    //         const response = await axios.delete(`http://localhost:8080/cidadao/apagar/${id}`);

    //         // A resposta do servidor estará em response.data
    //         console.log('Cidadao deletado com sucesso:', response.data);

    //         // Você pode retornar uma mensagem ou o que for necessário
    //         return response.data;
    //     } catch (error) {
    //         console.error('Erro ao deletar o cidadão:', error);
    //         // Retorne uma mensagem de erro, se necessário
    //         return 'Erro ao deletar o cidadão';
    //     }
    // };
    //++++++++++++++++++++++++++++++++++
    const { setFormData } = useContext(FormContext); // Acesso ao contexto para atualizar os dados
    const navigate = useNavigate();

    const {
        register,
        handleSubmit,
        formState: { errors },
    } = useForm();

    // Função para verificar se o usuário existe com base nos dados fornecidos
    const verificarUsuario = async (email, senha) => {
        try {
            // Requisição GET para buscar cidadãos
            const resposta = await axios.get('http://localhost:8080/cidadao/todos');
            const cidadaos = resposta.data;

            // Verifica se algum cidadão tem o mesmo e-mail e senha
            const usuarioExistente = cidadaos.find(
                (cidadao) => cidadao.email === email && cidadao.senha === senha
            );
            console.log("Usuário encontrado (JSON):", JSON.stringify(usuarioExistente, null, 2));


            return usuarioExistente;
        } catch (erro) {
            console.error('Erro ao buscar os cidadãos:', erro);
            return null;
        }
    };

    // Função para manipular o envio do formulário
    const onSubmit = async (data) => {
        const { email, senha } = data;

        // Verifica se o usuário com as mesmas informações existe
        const usuario = await verificarUsuario(email, senha);

        if (usuario) {
            setFormData(usuario); // Atualiza o FormContext com os dados do formulário
            // console.log("data: " + data)
            // console.log("usuario: " + usuario)

            alert("Login realizado com sucesso!");
            navigate('/'); // Redireciona para a página principal

        } else {
            alert("Usuário não encontrado!"); // Exibe alert caso o usuário não exista
        }
    };

    return (
        <main id={styles.login}>
            <form onSubmit={handleSubmit(onSubmit)} autoComplete="off">
                <h1>Login</h1>
                <div className={styles.boxInput}>
                    <label htmlFor="iemail">Email:</label>
                    <input
                        type="email"
                        name="email"
                        id="iemail"
                        {...register("email", {
                            required: "O email é obrigatório",
                            pattern: {
                                value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                                message: "Digite um email válido"
                            }
                        })}
                    />
                    {errors.email && <p>{errors.email.message}</p>}
                </div>
                <div className={styles.boxInput}>
                    <label htmlFor="isenha">Senha:</label>
                    <input type="password" name="senha" id="isenha"
                        {...register("senha", {
                            required: "A senha é obrigatória",
                        })}
                    />
                    {errors.senha && <p>{errors.senha.message}</p>}
                </div>
                <div className={styles.lembrar}>
                    <Link to={"/AlterarSenha"}>esqueceu a senha?</Link>
                </div>
                <div id={styles.botao}>
                    <button className={styles.btn} type="submit">Entrar</button>
                </div>
                <div className={styles.registrar}>
                    <p>Não tem uma conta?</p>
                    <p>
                        <Link to={"/Cadastro"}>Registrar-se</Link>
                    </p>
                </div>
            </form>
        </main>
    );
}

export default Login;
