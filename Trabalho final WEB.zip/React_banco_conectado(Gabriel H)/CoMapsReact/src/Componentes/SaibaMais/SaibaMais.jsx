import styles from './Saiba.module.css';
import imageDeslizamentoSp from '../../img/saibaMais/deslizamentoSp.jpg';
import imageDeslizamentoBR from '../../img/saibaMais/deslizamentoBR.jpg';
import imageEnchente from '../../img/saibaMais/deslizamentoBR.jpg';

function SaibaMais(){
    return(
        <main className={styles.saibaMais}>
            <div className={styles.container}>
                <h1>Nossa missão</h1>
                <div className={styles.geologico}>
                    <h2>Riscos Geologicos</h2>
                    <img src={imageDeslizamentoSp} alt="deslizamento no litoral norte de SP" />
                    <p>
                    Todo ano durante o período de chuvas vemos repetidas vezes em comunidades construídas, desastres que geram perdas inestimáveis aos moradores, seja essa perda de cunho material ou até a própria vida, essas pessoas muito ouvem sobre áreas de risco, mas não tem o conhecimento pleno sobre o que é esse risco, e muitos não sabem se realmente moram em uma dessas areas, e pensando nisso que a connect maps nasceu, para trazer essas informações de forma acessível para melhor conscientizar a população. Para tornar mais compreensível que tipos de risco estamos lidando vamos primeiro caracterizá-lo e descrevê-lo:
                    </p>
                    <p>Mas o que é risco? De acordo com a defesa civil risco é:</p>
                    <p><em>O termo "risco", na Doutrina Brasileira de Defesa Civil, foi conceituado como: relação existente entre a probabilidade de que uma ameaça de evento adverso ou acidente determinado se concretize, com o grau de vulnerabilidade do sistema receptor a seus efeitos.</em></p>
                </div>


                <div className={styles.deslizamento}>
                    <h2>Deslizamento</h2>
                    <img src={imageDeslizamentoBR} alt="deslizamento em rodovia"/>
                    
                    <p>Deslizamentos são fenômenos provocados pelo escorregamento de materiais sólidos, como solos, rochas, vegetação e/ou material de construção ao longo de terrenos inclinados, denominados de “encostas”, “pendentes” ou “escarpas”</p>
                    <p><em>"de  1991  a  2012, 388  municípios  apresentaram  um  total  de  699  ocorrências  de deslizamento de solo totalizando 535 mortes.
                    Na região Sudeste, 305 municípios registraram 558 ocorrências de deslizamento totalizando 3.980.016 pessoas afetadas e 525 mortes. Apenas no  estado  de  São  Paulo,  93  municípios  registraram  165  ocorrências  no  mesmo  período.”</em></p>
                    <a href="http://www.spalerta.sp.gov.br/topicos/deslizamentos">O que fazer?</a>
                </div>

                <div className={styles.inundacao}>
                    <h2>Inundação/Enchentes</h2>
                    <img src={imageEnchente} alt="enchente"/>
                    <p>
                        Inundações consistem na concentração de águas de chuva devido à ineficiência de absorção pelo solo ou outras formas de escoamento.
                        Algumas causas que contribuem para esse evento são o desmatamento de encostas; assoreamento dos rios; acúmulo de lixo nos bueiros e rios; insuficiência da rede de galerias pluviais; e pavimentação de ruas e construção de calçadas, reduzindo a superfície de infiltração.
                    </p>
                    <a href="http://www.spalerta.sp.gov.br/topicos/inundacoes/">O que fazer?</a>
                    <p>Por: Equipe Connect Maps</p>
                </div>
            </div>
            
        </main>
    )
}
export default SaibaMais