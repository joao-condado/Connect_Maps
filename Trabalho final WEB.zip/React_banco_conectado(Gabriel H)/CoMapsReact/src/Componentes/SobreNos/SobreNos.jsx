import styles from './Nos.module.css';
import imageGian from '../../img/pessoas/Gian.jpeg';
import imageGabriel from '../../img/pessoas/Gabriel.jpeg';
import imageJGabriel from '../../img/pessoas/JGabriel.png';
import imageJBatista from '../../img/pessoas/JBatista.jpg';

function SobreNos(){
    return(
        <main className={styles.nos}>
            <h1>Membros da equipe desenvolvedora</h1>
            <div className={styles.container_esquerda}>
                <div className={styles.foto_esquerda}>
                    <img src={imageGian}/>
                </div>
                <div className={styles.desc_pessoas_esquerda}>
                    <h3>Gian Paulo Marques de lima</h3>
                    <p>
                        Desenvolvedor Front-End e Brainstormer de avanços do projeto, Gian, de 16 anos, é
                        um mestre no que se trata de gerar ideias e desenvolvê-las com maestria.
                        Entrou na equipe de desenvolvimento logo em sua formação, e desde então serve como uma
                        engrenagem essencial para o funcionamento deste gigantesco sistema
                        que é o <span className="spam">Connect Maps</span>.
                    </p>
                </div>
            </div>

            <div className={styles.container_direita}>
                <div className={styles.foto_direita}>
                    <img src={imageGabriel}/>
                </div>
                <div className={styles.desc_pessoas_direita}>
                    <h3>Gabriel Henrique de Oliveira</h3>
                    <p>
                        Co-fundador do projeto e Product Owner do mesmo, Gabriel Henrique é essencial quando se trata
                        da compreensão do projeto em larga escala. Cumprindo a função de representar os desejos do
                        usuário e visões futuras de possíveis melhorias, Gabriel Henrique agrega cada vez mais ao
                        <span className="spam"> Connect Maps</span>.
                    </p>
                </div>
            </div>




            <div className={styles.container_esquerda}>
                <div className={styles.foto_esquerda}>
                    <img src={imageJGabriel}/>
                </div>
                <div className={styles.desc_pessoas_esquerda}>
                    <h3>João Gabriel Barbosa Camilo</h3>
                    <p>
                        Agindo como a parte prática do Projeto, nosso desenvolvedor Back-End e Co-fundador do projeto,
                        João Gabriel é vital no desenvolvimento físico das ideias abstraídas por processador de Brainstorming,
                        tornando-as realidade.
                    </p>
                </div>
            </div>

            <div className={styles.container_direita}>
                <div className={styles.foto_direita}>
                    <img src={imageJBatista}/>
                </div>
                <div className={styles.desc_pessoas_direita}>
                    <h3>João Batista Condado de Carvalho</h3>
                    <p>
                        O Scrum Master João Batista é um resolvedor de problemas e criador de soluções para facilitar a
                        prática de desenvolvimento da equipe. É importante também na tomada de decisões e organização da
                        equipe para que todos estejam sempre na mesma página.
                    </p>
                </div>
            </div>
        </main>
    )
}
export default SobreNos