import { Link } from "react-router-dom"
import styles from "./Cadastro.module.css";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom"; //hook de navegação programável


function Cadastro() {

  const navigate = useNavigate(); // Inicializando o hook de navegação
    const {
        register,
        handleSubmit,
        watch,
        formState: { errors },
  } = useForm();

  const onSubmit = (data) => {
    console.log(data);
    navigate('/Login'); // Caminho para a página de login
    alert(JSON.stringify(data, null, 2));  // Exibe o objeto como string no alert
    criarCidadao(data);

  };

    //inspeciona o valor do campo senha
    const senha = watch("senha");

    async function criarCidadao(data) {
      // Variável predefinida
      const novoCidadao = data;

      try {
          const response = await fetch('http://localhost:8080/cidadao/criarUsuarioCidadao', {
              method: 'POST',
              headers: {
                  'Content-Type': 'application/json',
              },
              body: JSON.stringify(novoCidadao),
          });

          if (response.ok) {
              const result = await response.text(); // Pega a resposta como texto
              console.log('Postagem bem-sucedida:', result);
          } else {
              console.error('Erro na requisição:', response.status, response.statusText);
          }
      } catch (error) {
          console.error('Erro ao enviar a requisição:', error);
      }
  }

    return (
        <main id={styles.cadastro} >
            <form  id="form" autoComplete="off" onSubmit={handleSubmit(onSubmit)}>
                <h1>Cadastro</h1>

                <div className={styles.boxInput}>
                    <label htmlFor="inome">Nome:</label>
                    <input type="text" name="nome" id="inome"
                    {...register("nome", { required: "O nome é obrigatório" })} 
                    placeholder="Digite seu nome"
                    />
                    {errors.nome && <p >{errors.nome.message}</p>}
                </div>

                <div className={styles.boxInput}>
                    <label htmlFor="iemail">Email:</label>
                    <input type="email" name="email" id="iemail"
                    {...register("email", {
                        required: "O email é obrigatório",
                        pattern: {
                          value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                          message: "Digite um email válido"
                        }
                      })}
                    />
                    {errors.email && <p>{errors.email.message}</p>}
                </div>

                <div className={styles.boxInput}>
                    <label htmlFor="itelefone">Telefone:</label>
                    <input type="tel" name="telefone" id="itelefone"
                    {...register("telefone", {
                        required: "O telefone é obrigatório",
                        pattern: {
                          value: /^(\+55\s?)?(\(?\d{2}\)?\s?)?(\d{5})\-?\d{4}$/,
                          message: "Digite um telefone válido"
                        }
                      })}
                    />
                    {errors.telefone && <p style={{ color: "red" }}>{errors.telefone.message}</p>}
                </div>

                <div className={styles.boxInput}>
                    <label htmlFor="isenha">Senha:</label>
                    <input type="password" name="senha" id="isenha"
                    {...register("senha", {
                        required: "A senha é obrigatória",
                        pattern: {
                          value: /^.{6,}$/,
                          message: "A senha deve conter no mínimo 6 caracteres",
                        }
                      })} 
                    />
                    {errors.senha && <p>{errors.senha.message}</p>}
                </div>

                <div className={styles.boxInput}>
                    <label htmlFor="iconfirmacao">Confirmação de senha:</label>
                    <input type="password" name="confirmacao" id="iconfirmacao"
                    {...register("confirmacao", {
                        required: "A confirmação de senha é obrigatória",
                        //funcionalidade do react-hook-form para validar um campo especifico
                        validate: (value) =>
                          value === senha || "As senhas não coincidem",
                      })} 
                    />
                    {errors.confirmacao && <p>{errors.confirmacao.message}</p>} 
                </div>

                <div id={styles.botao}>
                    <button className={styles.btn} type="submit">Entrar</button>
                </div>

                <div className={styles.registrar}>
                    <p>Já tem uma conta?</p>
                    <p>
                        <Link to={"/Login"}>Login</Link>
                    </p>
                </div>
            </form>
        </main>

    );
}

export default Cadastro;