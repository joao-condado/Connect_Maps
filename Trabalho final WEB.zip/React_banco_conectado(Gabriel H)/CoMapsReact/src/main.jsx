import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
// react router
import { createBrowserRouter, RouterProvider } from "react-router-dom"

// importando paginas
import Main from './Componentes/Main/Main.jsx';
import SaibaMais from './Componentes/SaibaMais/SaibaMais.jsx';
import SobreNos from './Componentes/SobreNos/SobreNos.jsx';
import Error from './Componentes/Error/Error.jsx'
//
import Login from './Componentes/Login/Login.jsx'
import Cadastro from './Componentes/Cadastro/Cadastro.jsx'
import Denuncia from './Componentes/Denuncia/Denuncia.jsx';
//
import AlterarSenha from './Componentes/AlterarSenha/AlterarSenha.jsx'
import AtualizarDenuncia from './Componentes/AtualizarDenuncia/AtulizarDenuncia.jsx'

const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    errorElement: <Error />,
    children: [
      {
        path: "/",
        element: <Main />
      },
      {
        path: "SobreNos",
        element: <SobreNos />
      },
      {
        path: "SaibaMais",
        element: <SaibaMais />
      },
      {
        path: "Login",
        element: <Login />
      },
      {
        path: "Cadastro",
        element: <Cadastro />
      },
      {
        path: "Denuncia",
        element: <Denuncia />
      },
      {
        path: "AlterarSenha",
        element: <AlterarSenha />
      },
      {
        path: "AtualizarDenuncia/{id}",
        element: <AtualizarDenuncia />
      }

    ]
  }
])

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <RouterProvider router={router} />
  </StrictMode>,
)
