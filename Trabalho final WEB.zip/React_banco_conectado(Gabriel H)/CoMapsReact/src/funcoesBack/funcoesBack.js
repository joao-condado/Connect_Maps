import React, { useEffect, useState } from "react";
import axios from "axios";
import styles from "./todo.module.css";

// Função principal
export default function ToDo() {
  const [pessoas, setPessoas] = useState([]);
  const [newPerson, setNewPerson] = useState({ nome: "", email: "", numero: "" });
  const [editPerson, setEditPerson] = useState(null); // Para editar pessoa existente

  // Carrega pessoas ao montar o componente
  useEffect(() => {
    
    const fetchPessoas = async () => {
      try {
        const response = await axios.get("https://jsonplaceholder.typicode.com/users");
        setPessoas(response.data); // Exibe todas as pessoas
      } catch (error) {
        console.error("Erro ao buscar pessoas:", error);
      }
    };

    fetchPessoas();
  }, []); // Array de dependências vazio para rodar apenas uma vez

  // Função para adicionar pessoa (POST)
  const addPerson = async () => {
    if (!newPerson.nome || !newPerson.email || !newPerson.numero) {
      alert("Preencha todos os campos.");
      return;
    }

    try {
      const response = await axios.post(
        "https://jsonplaceholder.typicode.com/users",
        {
          name: newPerson.nome,
          email: newPerson.email,
          phone: newPerson.numero,
        }
      );
      setPessoas((prevPessoas) => [...prevPessoas, response.data]);
      setNewPerson({ nome: "", email: "", numero: "" });
    } catch (error) {
      console.error("Erro ao adicionar pessoa:", error);
    }
  };

  // Função para editar pessoa
  const editPersonData = (person) => {
    setEditPerson(person);
    setNewPerson({ nome: person.name, email: person.email, numero: person.phone });
  };

  // Função para atualizar pessoa (PUT)
  const updatePerson = async () => {
    if (!newPerson.nome || !newPerson.email || !newPerson.numero) {
      alert("Preencha todos os campos.");
      return;
    }

    try {
      const response = await axios.put(
        `https://jsonplaceholder.typicode.com/users/${editPerson.id}`,
        {
          name: newPerson.nome,
          email: newPerson.email,
          phone: newPerson.numero,
        }
      );
      setPessoas((prevPessoas) =>
        prevPessoas.map((person) =>
          person.id === editPerson.id ? { ...person, ...response.data } : person
        )
      );
      setNewPerson({ nome: "", email: "", numero: "" });
      setEditPerson(null); // Limpa o estado de edição
    } catch (error) {
      console.error("Erro ao atualizar pessoa:", error);
    }
  };

  // Função para deletar pessoa (DELETE)
  const deletePerson = async (id) => {
    try {
      await axios.delete(`https://jsonplaceholder.typicode.com/users/${id}`);
      setPessoas((prevPessoas) => prevPessoas.filter((person) => person.id !== id));
    } catch (error) {
      console.error("Erro ao deletar pessoa:", error);
    }
  };

  return (
    <div>
      <h1>Cadastro de Pessoas</h1>
      <input
        type="text"
        value={newPerson.nome}
        onChange={(e) => setNewPerson({ ...newPerson, nome: e.target.value })}
        placeholder="Nome"
      />
      <input
        type="email"
        value={newPerson.email}
        onChange={(e) => setNewPerson({ ...newPerson, email: e.target.value })}
        placeholder="Email"
      />
      <input
        type="text"
        value={newPerson.numero}
        onChange={(e) => setNewPerson({ ...newPerson, numero: e.target.value })}
        placeholder="Número"
      />
      <button onClick={editPerson ? updatePerson : addPerson}>
        {editPerson ? "Atualizar Pessoa" : "Cadastrar Pessoa"}
      </button>
      <ul>
        {pessoas.map((pessoa) => (
          <li className={styles.listItem} key={pessoa.id}>
            <p><strong>Nome:</strong> {pessoa.name}</p>
            <p><strong>Email:</strong> {pessoa.email}</p>
            <p><strong>Telefone:</strong> {pessoa.phone}</p>
            <button onClick={() => editPersonData(pessoa)}>Editar</button>
            <button onClick={() => deletePerson(pessoa.id)}>Excluir</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
