import React, { createContext, useState, useEffect } from 'react';
import axios from 'axios';


// 1. Criar o contexto
export const FormContext = createContext();

// 2. Criar o Provider
export const FormProvider = ({ children }) => {
    const [formData, setFormData] = useState(
            {
                name: '',
                email: ''
            }
        );
    
    const [denuncias, setDenuncias] = useState([]);

        // 4. useEffect para buscar as denúncias assim que o componente for montado
    useEffect(() => {
        const fetchDenuncias = async () => {
            try {
                const response = await axios.get('http://localhost:8080/denuncia/todos');
                setDenuncias(response.data);  // Armazenando as denúncias recebidas no estado
            } catch (error) {
                console.error('Erro ao buscar as denúncias:', error);
            }
        };
    
        fetchDenuncias();  // Chama a função para pegar as denúncias
    }, []);

    

    return (
        <FormContext.Provider value={{ formData, setFormData, denuncias }}>
            {children}
        </FormContext.Provider>
    );
};
