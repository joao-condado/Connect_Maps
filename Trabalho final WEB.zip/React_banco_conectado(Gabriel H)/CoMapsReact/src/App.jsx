
import './App.css'
//
import Header from './Componentes/Header/Header'
// import Main from './Componentes/Main/Main'
import Footer from './Componentes/Footer/Footer'
//
// import SaibaMais from './Componentes/SaibaMais/SaibaMais'
// import SobreNos from './Componentes/SobreNos/SobreNos'
//
import { Outlet } from 'react-router-dom'
import { FormProvider } from './Context/FormContext'
//


function App() {

  return (
    <FormProvider>
      <Header />
      <Outlet />
      <Footer />
    </ FormProvider>
  )
}

export default App
